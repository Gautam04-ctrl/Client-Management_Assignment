
const express=require('express');
const bodyParser=require('body-parser');
const cors=require('cors');
const mysql=require('mysql2');
const { error } = require('console');


const app=express();
const port=3000;
app.use(cors({
    origin: "http://localhost:4200",  
    methods: ["GET","POST"],
    credentials: true

}));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());



const db= mysql.createConnection({
host:'localhost',
database:'angularproject13',
user:'root',
password:'Sanjay@30'
});



db.connect(err=>{
   if(err){
       console.error('connection failed check the db details ',err);
   }
   else{
       console.log('connection is done with the mysql database')
   }
});



app.listen(port,()=>{console.log('server port is up on 3000')})



app.post('/addRegistration',(req,res)=>{

const {name,email,address,password,repeat_password}=req.body;
const sql='insert into registration (name,email,address,password,repeat_password) values(?,?,?,?,?)';

  console.log('Incoming registration:', req.body);

db.query(sql,[name,email,address,password,repeat_password],(err,result)=>{
    if(err){
        console.error('Error in adding the registration details:',err);
        res.status(500).send({error:'An error occured'});
    }
    else{
        console.log("successfully inserted the registration details.Insert ID:",result.insertId);
        res.status(200).json({message:'Successfully registerd for client meeting'});
       
    }
  
});
});



app.post('/addLogin',(req,res)=>{
   const {email,password}=req.body;

   console.log("Login attempt with:", email, password); 

  const sql = 'SELECT * FROM registration WHERE email=? AND password=?';
db.query(sql,[email,password],(err,results)=>{
   if(err){
       console.error('Error in adding the login details',err);
       res.status(500).send({error:'An error occured'});
   }
  
  else if (results.length > 0) {
      console.log('Login successful');
     
     res.status(200).json({ message: 'Login successful' });
    } else {
      console.log(' Invalid login');
      res.status(401).send('Invalid email or password');
    }
});
});


app.post('/addSchedule',(req,res)=>{
   const {meeting_topic,number_of_people,date_time}=req.body;
const sql='insert into schedule (meeting_topic,number_of_people,date_time) values(?,?,?)';

const mysqlDatetime = date_time.replace('T', ' ') + ':00';

db.query(sql,[meeting_topic,number_of_people,date_time],(err,result)=>{
   if(err){
       console.error('Error in adding the schedule details:',err.sqlMessage);
       return res.status(500).send({error:err.sqlMessage})
   }
   else{
       console.log("successfully inserted the schedule details")
        res.send('Successfully scheduled client meeting');
   }
});
});







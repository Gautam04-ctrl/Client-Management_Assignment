import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { error } from 'console';
import { response } from 'express';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {

email:string='';
password:string='';


  constructor(private http: HttpClient, private router: Router) {}


login() {
    const body = { email: this.email, password: this.password };

    this.http.post('http://localhost:3000/addLogin',  body, { responseType: 'text' })
      .subscribe({
        next: (res:any) => {
         // alert('Login successful! Redirecting to schedule...');
          this.router.navigate(['/schedule']);
        },
        error: err => {
          console.error('Login failed', err);
          alert('Invalid credentials. Try again.');
        }
      });
  }
}




import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-schedule',
  standalone: false,
  templateUrl: './schedule.html',
  styleUrl: './schedule.css'
})
export class Schedule {

meeting_topic: string = '';
number_of_people: number | null = null;
date_time: string = '';

  constructor(private http: HttpClient) {}

  schedule() {
    const body = {
      meeting_topic: this.meeting_topic,
      number_of_people: this.number_of_people,
      date_time: this.date_time
    };
       console.log('Schedule body:', body);

    this.http.post('http://localhost:3000/addSchedule', body, { responseType: 'text' })
      .subscribe({
        next: () => {
          alert('Meeting scheduled successfully!');
          
        },
        error: err => {
          console.error('Schedule failed', err);
          alert('Failed to schedule meeting. Try again.');
        }
      });
  }
}
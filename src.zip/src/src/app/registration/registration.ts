import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  standalone: false,
  templateUrl: './registration.html',
  styleUrl: './registration.css'
})
export class Registration {

name:string='';
email:string='';
address:string='';
password:string='';
repeat_password:string='';




constructor(private http: HttpClient, private router: Router) {}


registration(){


 const body={
  name:this.name,
  email:this.email,
  address:this.address,
  password:this.password,
  repeat_password:this.repeat_password
 };


 this.http.post('http://localhost:3000/addRegistration',body)
.subscribe({

next: () => {
          //alert('Registered successfully! Redirecting to login...');
          this.router.navigate(['/login']);
        },
        error: err => {
          console.error(' Registration failed', err);
          alert('Registration failed. Try again.');
        }
      });
  }

}